Ayaka Exposed in Hyoukai Sonata Mod made by Lewd Lad (with Assistance from AGMG's HazrateGolabi)

Provided under 
Creative_Commons_Attribution-NonCommercial-NoDerivatives_4.0_International_CC_BY-NC-ND_4.0

No commercial usage.

If you wish to make media using this mod, please contact me via Patreon, Game Banana or Twitter.

No derivative works allowed.

Available on Patreon for Early Access or from Game Banana for Public Release.
www.patreon.com/Lewd_lad
https://gamebanana.com/members/2216893
Twitter@LewdLadModding

If you paid for this mod outside of early access on Patreon, you were cheated. 
Let me know and I'll see what I can do about it.